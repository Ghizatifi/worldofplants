import { ViewChild,Component, OnInit, ElementRef } from '@angular/core';
import { NavParams, ModalController, Platform, LoadingController, AlertController } from '@ionic/angular';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { TranslateService } from '@ngx-translate/core';

declare var google;

@Component({
  selector: 'app-map',
  templateUrl: './map.page.html',
  styleUrls: ['./map.page.scss'],
})
export class MapPage implements OnInit {
  @ViewChild('mapElement', {static: false}) mapElement: ElementRef;
  public lat:any;
  public lng:any;
  public map:any;
  public myLat:any;
  public myLng:any;
  public myLocationMarker:any;
  public focusLoading:any;
  constructor(
    private navParams: NavParams,
    private geolocation: Geolocation,
    private modalCtrl: ModalController,
    private platform: Platform,
    private loadingCtrl: LoadingController,
    private translate: TranslateService,
    private alertCtrl: AlertController,
  ) { }

  async ngOnInit() {
    let loading = await this.loadingCtrl.create({
      message: this.translate.getParsedResult("en","Loading")+"...",
      duration: 1500
    });
    loading.present();
    setTimeout(()=> {
      this.loadMap();
      // var subscription = this.deviceOrientation.watchHeading().subscribe(
      //   (data: DeviceOrientationCompassHeading) => console.log(this.convertToText(data.magneticHeading))
      // );      
    }, 1000);
    
  }

  convertToText(mh) {
    var textDirection;
    if (typeof mh !== "number") {
      textDirection = ''; 
    } else if (mh >= 337.5 || (mh >= 0 &&  mh <= 22.5)) {
      textDirection =  'N'; 
    } else if (mh >= 22.5 && mh <= 67.5) {
       textDirection =  'NE'; 
    } else if (mh >= 67.5 && mh <= 112.5) {
       textDirection =  'E'; 
    } else if (mh >= 112.5 && mh <= 157.5) {
       textDirection =  'SE'; 
    } else if (mh >= 157.5 && mh <= 202.5) {
       textDirection =  'S'; 
    } else if (mh >= 202.5 && mh <= 247.5) {
       textDirection =  'SW'; 
    } else if (mh >= 247.5 && mh <= 292.5) {
       textDirection =  'W'; 
    } else if (mh >= 292.5 && mh <= 337.5) {
       textDirection =  'NW'; 
    } else {
      textDirection =  textDirection;
    }
    return textDirection;
  }
  
  public loadMap() {
    this.platform.ready().then(()=> {
      console.log("Entered");
      let mapElement = document.createElement("div");
      mapElement.style.width = '100%';
      mapElement.style.height = '100%';
      mapElement.id = "map" + (Math.random()*100);
      let container = document.getElementById('map-container');
      container.childNodes.forEach((el)=> {
        el.remove();
      });
      container.appendChild(mapElement);
      let latLng = new google.maps.LatLng(23.8141536,54.0995627);
   
      let mapOptions = {
        center: latLng,
        zoom: 15,
        // mapTypeId: google.maps.MapTypeId.ROADMAP,
        panControl: false,
        zoomControl: false,
        mapTypeControl: false,
        scaleControl: true,
        streetViewControl: false,
        overviewMapControl: false,
        rotateControl: true,
        fullscreenControl: false,
        styles: [
          {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#d6e2e6"
              }
            ]
          },
          {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [
              {
                "color": "#cfd4d5"
              }
            ]
          },
          {
            "featureType": "administrative",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#7492a8"
              }
            ]
          },
          {
            "featureType": "administrative.neighborhood",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "lightness": 25
              }
            ]
          },
          {
            "featureType": "landscape.man_made",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#dde2e3"
              }
            ]
          },
          {
            "featureType": "landscape.man_made",
            "elementType": "geometry.stroke",
            "stylers": [
              {
                "color": "#cfd4d5"
              }
            ]
          },
          {
            "featureType": "landscape.natural",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#dde2e3"
              }
            ]
          },
          {
            "featureType": "landscape.natural",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#7492a8"
              }
            ]
          },
          {
            "featureType": "landscape.natural.terrain",
            "stylers": [
              {
                "visibility": "off"
              }
            ]
          },
          {
            "featureType": "poi",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#dde2e3"
              }
            ]
          },
          {
            "featureType": "poi",
            "elementType": "labels.icon",
            "stylers": [
              {
                "saturation": -100
              }
            ]
          },
          {
            "featureType": "poi",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#588ca4"
              }
            ]
          },
          {
            "featureType": "poi.park",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#a9de83"
              }
            ]
          },
          {
            "featureType": "poi.park",
            "elementType": "geometry.stroke",
            "stylers": [
              {
                "color": "#bae6a1"
              }
            ]
          },
          {
            "featureType": "poi.sports_complex",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#c6e8b3"
              }
            ]
          },
          {
            "featureType": "poi.sports_complex",
            "elementType": "geometry.stroke",
            "stylers": [
              {
                "color": "#bae6a1"
              }
            ]
          },
          {
            "featureType": "road",
            "elementType": "labels.icon",
            "stylers": [
              {
                "saturation": -45
              },
              {
                "lightness": 10
              },
              {
                "visibility": "on"
              }
            ]
          },
          {
            "featureType": "road",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#41626b"
              }
            ]
          },
          {
            "featureType": "road.arterial",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#ffffff"
              }
            ]
          },
          {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#c1d1d6"
              }
            ]
          },
          {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [
              {
                "color": "#a6b5bb"
              }
            ]
          },
          {
            "featureType": "road.highway",
            "elementType": "labels.icon",
            "stylers": [
              {
                "visibility": "on"
              }
            ]
          },
          {
            "featureType": "road.highway.controlled_access",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#9fb6bd"
              }
            ]
          },
          {
            "featureType": "road.local",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#ffffff"
              }
            ]
          },
          {
            "featureType": "transit",
            "elementType": "labels.icon",
            "stylers": [
              {
                "saturation": -70
              }
            ]
          },
          {
            "featureType": "transit.line",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#b4cbd4"
              }
            ]
          },
          {
            "featureType": "transit.line",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#588ca4"
              }
            ]
          },
          {
            "featureType": "transit.station",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#008cb5"
              }
            ]
          },
          {
            "featureType": "transit.station.airport",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "saturation": -100
              },
              {
                "lightness": -5
              }
            ]
          },
          {
            "featureType": "water",
            "elementType": "geometry.fill",
            "stylers": [
              {
                "color": "#a6cbe3"
              }
            ]
          }
        
        ]
      }
   
      this.map = new google.maps.Map(mapElement, mapOptions);
      // this.map.setCenter(latLng);
      if (this.navParams.get('lat') && this.navParams.get('lng')) {
        this.lat = this.navParams.get('lat');
        this.lng = this.navParams.get('lng');
        this.map.setCenter(new google.maps.LatLng(this.lat, this.lng));
        this.map.setZoom(15);
        console.log("GOT", this.lat, this.lng);
      }
      // google.maps.event.addListener(this.map, "idle", function(){
        google.maps.event.trigger(this.map, 'resize'); 
      // });
      this.getLocation();
      setInterval(()=>{ this.getLocationInterval(); }, 3000);

    })
  }

  public async focusMap(showLoading:boolean=false, retryIfError:boolean =false) {
    if (showLoading) {
      this.focusLoading = await this.loadingCtrl.create({
        message: this.translate.getParsedResult('en', 'Loading')+'...'
      });
      this.focusLoading.present();
    }
    this.geolocation.getCurrentPosition({
      enableHighAccuracy: true
    }).then((resp)=> {
      if (resp  && resp.coords && resp.coords.latitude && resp.coords.longitude) {
        this.map.setCenter(new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude));
      }
      else if (retryIfError == true) this.focusMap(false, true);

    }, error=> {
      if (retryIfError == true) this.focusMap(false, true);
    })
  }
  public getLocation(tries:number=0) {
      this.geolocation.watchPosition(
        {
          enableHighAccuracy: true
        }
      ).subscribe(resp => {
        // alert("1تم التقاط الموقع الجديد");
        if (resp  && resp.coords && resp.coords.latitude && resp.coords.longitude) {
          this.myLat = resp.coords.latitude;
          this.myLng = resp.coords.longitude;
          if (this.myLocationMarker)  {
            this.myLocationMarker.setPosition(new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude));
          }
          else {
            this.map.setCenter(new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude));
            let marker = new google.maps.Marker({
              position: new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude),
              map: this.map,
              icon: {
                url: "assets/images/bus.png",
                anchor: new google.maps.Point(0, 0),
                // url: 'assets/images/user-location.png',
                // scaledSize: new google.maps.Size(30, 24), // scaled size
                // origin: new google.maps.Point(0,0), // origin
                // anchor: new google.maps.Point(0, 0) // anchor
               },
          });
          this.myLocationMarker = marker;
          }
        }
      }, async (error) => {
        console.log("ERROR:", error);
        if (tries <= 5)
        this.getLocation(tries+1);
        else {
          let alert = await this.alertCtrl.create({
            header: this.translate.getParsedResult("en", "Error"),
            message: this.translate.getParsedResult("en", "Please active your GPS and try again"),
            buttons: [
              {
                text: this.translate.getParsedResult("en", "ok"),
                handler: ()=> {
                  this.modalCtrl.dismiss();
                }
              }
            ]
          });
          alert.present();
        }
      })
  }

  public getLocationInterval(tries:number=0) {
    this.geolocation.getCurrentPosition(
      {
        enableHighAccuracy: true
      }
    ).then(resp => {
      alert("تم التقاط الموقع الجديد2");
      if (resp  && resp.coords && resp.coords.latitude && resp.coords.longitude) {
        this.myLat = resp.coords.latitude;
        this.myLng = resp.coords.longitude;
        if (this.myLocationMarker)  {
          this.myLocationMarker.setPosition(new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude));
        }
        else {
          this.map.setCenter(new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude));
          let marker = new google.maps.Marker({
            position: new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude),
            map: this.map,
            icon: {
              url: "assets/images/bus.png",
              anchor: new google.maps.Point(0, 0),
              // url: 'assets/images/user-location.png',
              // scaledSize: new google.maps.Size(30, 24), // scaled size
              // origin: new google.maps.Point(0,0), // origin
              // anchor: new google.maps.Point(0, 0) // anchor
             },
        });
        this.myLocationMarker = marker;
        }
      }
    }, async (error) => {
      console.log("ERROR:", error);
      if (tries <= 5)
      this.getLocation(tries+1);
      else {
        let alert = await this.alertCtrl.create({
          header: this.translate.getParsedResult("en", "Error"),
          message: this.translate.getParsedResult("en", "Please active your GPS and try again"),
          buttons: [
            {
              text: this.translate.getParsedResult("en", "ok"),
              handler: ()=> {
                this.modalCtrl.dismiss();
              }
            }
          ]
        });
        alert.present();
      }
    })
}
  public ok() {
    let target = this.map.getCenter();
  console.log('LAT, LNG: ' + target);
  target= target.toString().replace('(','').replace(')', '').replace(' ', '').split(',');
  console.log('LAT, LNG: ' + target);
  target[0] = Math.round(target[0] * 1000000) / 1000000;
  target[1] = Math.round(target[1] * 1000000) / 1000000;
  this.modalCtrl.dismiss({
    lat: target[0],
    lng: target[1]
  });
  }

  public back() {
    this.modalCtrl.dismiss();
  }

}
